require("./bootstrap");
window.CKEDITOR_BASEPATH = "node_modules/ckeditor/";
require("ckeditor");
