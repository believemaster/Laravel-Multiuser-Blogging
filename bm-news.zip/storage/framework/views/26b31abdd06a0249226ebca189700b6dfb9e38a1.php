<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <section class="content-header">
        <?php if($message = Session::get('success')): ?>
          <div class="alert alert-success">
              <?php echo e($message); ?>

          </div>
        <?php endif; ?>
        <div class="col-md-12">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo e($page_name); ?></h3>

              <div class="box-tools pull-right">
                <div class="has-feedback">
                  <input type="text" class="form-control input-sm" placeholder="Search Mail">
                  <span class="glyphicon glyphicon-search form-control-feedback"></span>
                </div>
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body no-padding">
              <div class="table-responsive mailbox-messages">
                <table class="table table-hover table-striped">
                  <tbody>
                  <thead>
                  <td>S.No.</td>
                  <td>Name</td>
                  <td>Email</td>
                  <td>Message</td>
                  <td>Time</td>
                  </thead>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e(++$i); ?></td>
                    <td class="mailbox-name"><a href="<?php echo e(url('/admin/contacts/details')); ?>/<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a></td>
                    <td class="mailbox-name"><?php echo e($item->email); ?></td>
                    <td class="mailbox-subject"><b><?php echo e(str_limit($item->message, 100, '...')); ?></b>
                    </td>
                    <td class="mailbox-attachment"></td>
                    <td class="mailbox-date"><?php echo e($item->created_at->format('d/m/Y, H:i')); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                <!-- /.table -->
              </div>
              <!-- /.mail-box-messages -->
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->
        </section>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\bm-news\resources\views\admin\mailbox\contacts.blade.php ENDPATH**/ ?>