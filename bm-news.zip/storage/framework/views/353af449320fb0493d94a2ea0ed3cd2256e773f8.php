<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <section class="content-header">
    <div class="col-md-12">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo e($page_name); ?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body no-padding">
              <div class="mailbox-read-info">
                <h5>From: <?php echo e($data->email); ?>

                  <span class="mailbox-read-time pull-right"><?php echo e($data->created_at->format('d/m/Y, H:i')); ?></span></h5>
              </div>
              <!-- /.mailbox-read-info -->
              <div class="mailbox-read-message">
                <p><?php echo e($data->issue); ?></p>
              </div>
              <!-- /.mailbox-read-message -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
            <form method="post" action="<?php echo e(url('/admin/issues/delete/'.$data->id)); ?>" style="display:inline">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-default"><i class="fa fa-trash-o"></i> Delete</button>
            </form>
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->

    </section>
<div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\bm-news\resources\views\admin\mailbox\issuesDetails.blade.php ENDPATH**/ ?>