<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
    <section class="content-header">
      <h1>
        <?php echo e($page_name); ?>

      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Permissions</li>
      </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">

                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e($message); ?>

                        </div>
                    <?php endif; ?>

                    <div class="box-header">
                        <h3 class="box-title"><?php echo e($page_name); ?></h3>
                        <?php if (\Entrust::can(['Post Add', 'All'])) : ?>
                        <a href="<?php echo e(url('/admin/permission/create')); ?>" class="btn btn-sm btn-primary pull-right">Create</a>
                        <?php endif; // Entrust::can ?>
                    </div>
                    <div class="box-body">
                        <table id="example1" class="table table-bordered table-striped dt-responsive">
                        <thead>
                            <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Display Name</th>
                            <th>Description</th>
                            <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td><?php echo e(++$i); ?></td>
                            <td><?php echo e($row->name); ?></td>
                            <td><?php echo e($row->display_name); ?></td>
                            <td><?php echo e($row->description); ?></td>
                            <td>
                                <?php if (\Entrust::can(['Post Add', 'All'])) : ?>
                                <a href="<?php echo e(url('/admin/permission/edit/'.$row->id)); ?>" class="btn btn-xs btn-warning"><i class="fa fa-pencil"></i></a>
                                <?php endif; // Entrust::can ?>
                                <?php if (\Entrust::can(['Post Add', 'All'])) : ?>
                                <form method="post" action="<?php echo e(url('/admin/permission/delete/'.$row->id)); ?>" style="display:inline">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></button>
                                </form>
                                <?php endif; // Entrust::can ?>
                            </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
    </div>


    

    <script>
    $(function () {
        $('#example1').DataTable()
        $('#example2').DataTable({
        'paging'      : true,
        'lengthChange': false,
        'searching'   : false,
        'ordering'    : true,
        'info'        : true,
        'autoWidth'   : false
        })
    })
    </script>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\bm-news\resources\views\admin\permission\list.blade.php ENDPATH**/ ?>